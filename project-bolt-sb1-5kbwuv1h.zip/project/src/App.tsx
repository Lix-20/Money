import React, { useState } from 'react';
import { Plus, Wallet, ArrowUpRight, ArrowDownRight, PieChart, History, Target, Tags, Calendar } from 'lucide-react';

type Category = '餐饮' | '交通' | '购物' | '娱乐' | '居住' | '工资' | '投资' | '其他';

type Transaction = {
  id: string;
  amount: number;
  description: string;
  type: 'income' | 'expense';
  category: Category;
  date: string;
};

type Budget = {
  category: Category;
  limit: number;
};

function App() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [category, setCategory] = useState<Category>('其他');
  const [activeTab, setActiveTab] = useState<'overview' | 'add' | 'stats' | 'budget'>('overview');
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [newBudgetCategory, setNewBudgetCategory] = useState<Category>('餐饮');
  const [newBudgetLimit, setNewBudgetLimit] = useState('');

  const expenseCategories: Category[] = ['餐饮', '交通', '购物', '娱乐', '居住', '其他'];
  const incomeCategories: Category[] = ['工资', '投资', '其他'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newTransaction: Transaction = {
      id: Date.now().toString(),
      amount: parseFloat(amount),
      description,
      type,
      category,
      date: new Date().toISOString(),
    };
    setTransactions([newTransaction, ...transactions]);
    setAmount('');
    setDescription('');
  };

  const handleAddBudget = (e: React.FormEvent) => {
    e.preventDefault();
    const newBudget: Budget = {
      category: newBudgetCategory,
      limit: parseFloat(newBudgetLimit),
    };
    setBudgets([...budgets, newBudget]);
    setNewBudgetLimit('');
  };

  const balance = transactions.reduce((acc, curr) => 
    curr.type === 'income' ? acc + curr.amount : acc - curr.amount, 0
  );

  const income = transactions
    .filter(t => t.type === 'income')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const expenses = transactions
    .filter(t => t.type === 'expense')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const getCategoryTotal = (category: Category) => {
    return transactions
      .filter(t => t.category === category)
      .reduce((acc, curr) => acc + curr.amount, 0);
  };

  const getBudgetStatus = (category: Category) => {
    const budget = budgets.find(b => b.category === category);
    if (!budget) return null;
    
    const spent = transactions
      .filter(t => t.type === 'expense' && t.category === category)
      .reduce((acc, curr) => acc + curr.amount, 0);
    
    return {
      limit: budget.limit,
      spent,
      remaining: budget.limit - spent,
      percentage: (spent / budget.limit) * 100
    };
  };

  const getMonthlyStats = () => {
    const currentMonth = new Date().getMonth();
    const monthlyTransactions = transactions.filter(t => 
      new Date(t.date).getMonth() === currentMonth
    );

    return {
      income: monthlyTransactions
        .filter(t => t.type === 'income')
        .reduce((acc, curr) => acc + curr.amount, 0),
      expenses: monthlyTransactions
        .filter(t => t.type === 'expense')
        .reduce((acc, curr) => acc + curr.amount, 0)
    };
  };

  const monthlyStats = getMonthlyStats();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="max-w-4xl mx-auto p-6">
        <header className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Wallet className="w-8 h-8 text-indigo-600" />
            <h1 className="text-3xl font-bold text-gray-800">财务助手</h1>
          </div>
          <p className="text-gray-600">智能管理您的个人财务</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-gray-600">总余额</h3>
              <Wallet className="w-5 h-5 text-indigo-600" />
            </div>
            <p className="text-2xl font-bold text-gray-800">¥{balance.toFixed(2)}</p>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-gray-600">总收入</h3>
              <ArrowUpRight className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-2xl font-bold text-gray-800">¥{income.toFixed(2)}</p>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-gray-600">总支出</h3>
              <ArrowDownRight className="w-5 h-5 text-red-600" />
            </div>
            <p className="text-2xl font-bold text-gray-800">¥{expenses.toFixed(2)}</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between">
              <h3 className="text-gray-600">本月结余</h3>
              <Calendar className="w-5 h-5 text-purple-600" />
            </div>
            <p className="text-2xl font-bold text-gray-800">
              ¥{(monthlyStats.income - monthlyStats.expenses).toFixed(2)}
            </p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="flex border-b">
            <button
              className={`flex-1 px-6 py-4 text-sm font-medium transition-all duration-200 ease-in-out hover:bg-indigo-50 relative group ${
                activeTab === 'overview' 
                  ? 'text-indigo-600 border-b-2 border-indigo-600' 
                  : 'text-gray-600 hover:text-indigo-600'
              }`}
              onClick={() => setActiveTab('overview')}
            >
              <div className="flex items-center justify-center gap-2">
                <History className={`w-4 h-4 transition-transform duration-200 group-hover:scale-110 ${
                  activeTab === 'overview' ? 'text-indigo-600' : 'text-gray-500'
                }`} />
                <span>交易记录</span>
              </div>
              {activeTab === 'overview' && (
                <div className="absolute bottom-0 left-0 w-full h-0.5 bg-indigo-600 animate-slide-in" />
              )}
            </button>
            <button
              className={`flex-1 px-6 py-4 text-sm font-medium transition-all duration-200 ease-in-out hover:bg-indigo-50 relative group ${
                activeTab === 'add' 
                  ? 'text-indigo-600 border-b-2 border-indigo-600' 
                  : 'text-gray-600 hover:text-indigo-600'
              }`}
              onClick={() => setActiveTab('add')}
            >
              <div className="flex items-center justify-center gap-2">
                <Plus className={`w-4 h-4 transition-transform duration-200 group-hover:scale-110 ${
                  activeTab === 'add' ? 'text-indigo-600' : 'text-gray-500'
                }`} />
                <span>添加交易</span>
              </div>
              {activeTab === 'add' && (
                <div className="absolute bottom-0 left-0 w-full h-0.5 bg-indigo-600 animate-slide-in" />
              )}
            </button>
            <button
              className={`flex-1 px-6 py-4 text-sm font-medium transition-all duration-200 ease-in-out hover:bg-indigo-50 relative group ${
                activeTab === 'stats' 
                  ? 'text-indigo-600 border-b-2 border-indigo-600' 
                  : 'text-gray-600 hover:text-indigo-600'
              }`}
              onClick={() => setActiveTab('stats')}
            >
              <div className="flex items-center justify-center gap-2">
                <PieChart className={`w-4 h-4 transition-transform duration-200 group-hover:scale-110 ${
                  activeTab === 'stats' ? 'text-indigo-600' : 'text-gray-500'
                }`} />
                <span>统计分析</span>
              </div>
              {activeTab === 'stats' && (
                <div className="absolute bottom-0 left-0 w-full h-0.5 bg-indigo-600 animate-slide-in" />
              )}
            </button>
            <button
              className={`flex-1 px-6 py-4 text-sm font-medium transition-all duration-200 ease-in-out hover:bg-indigo-50 relative group ${
                activeTab === 'budget' 
                  ? 'text-indigo-600 border-b-2 border-indigo-600' 
                  : 'text-gray-600 hover:text-indigo-600'
              }`}
              onClick={() => setActiveTab('budget')}
            >
              <div className="flex items-center justify-center gap-2">
                <Target className={`w-4 h-4 transition-transform duration-200 group-hover:scale-110 ${
                  activeTab === 'budget' ? 'text-indigo-600' : 'text-gray-500'
                }`} />
                <span>预算管理</span>
              </div>
              {activeTab === 'budget' && (
                <div className="absolute bottom-0 left-0 w-full h-0.5 bg-indigo-600 animate-slide-in" />
              )}
            </button>
          </div>

          <div className="p-6">
            {activeTab === 'add' && (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    金额
                  </label>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="输入金额"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    描述
                  </label>
                  <input
                    type="text"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="输入描述"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    类型
                  </label>
                  <div className="flex gap-4">
                    <label className="flex items-center">
                      <input
                        type="radio"
                        checked={type === 'expense'}
                        onChange={() => {
                          setType('expense');
                          setCategory('餐饮');
                        }}
                        className="mr-2"
                      />
                      支出
                    </label>
                    <label className="flex items-center">
                      <input
                        type="radio"
                        checked={type === 'income'}
                        onChange={() => {
                          setType('income');
                          setCategory('工资');
                        }}
                        className="mr-2"
                      />
                      收入
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    分类
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as Category)}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  >
                    {(type === 'expense' ? expenseCategories : incomeCategories).map((cat) => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full bg-indigo-600 text-white py-3 px-4 rounded-lg hover:bg-indigo-700 transition-all duration-200 ease-in-out transform hover:scale-[1.02] hover:shadow-lg active:scale-[0.98] flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>添加交易</span>
                </button>
              </form>
            )}

            {activeTab === 'overview' && (
              <div className="space-y-4">
                {transactions.length === 0 ? (
                  <p className="text-center text-gray-500 py-4">暂无交易记录</p>
                ) : (
                  transactions.map((transaction) => (
                    <div
                      key={transaction.id}
                      className="flex items-center justify-between p-4 border rounded-lg"
                    >
                      <div>
                        <p className="font-medium">{transaction.description}</p>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-500">
                            {new Date(transaction.date).toLocaleDateString()}
                          </span>
                          <span className="text-sm px-2 py-1 bg-gray-100 rounded-full">
                            {transaction.category}
                          </span>
                        </div>
                      </div>
                      <p
                        className={`font-bold ${
                          transaction.type === 'income'
                            ? 'text-green-600'
                            : 'text-red-600'
                        }`}
                      >
                        {transaction.type === 'income' ? '+' : '-'}¥
                        {transaction.amount.toFixed(2)}
                      </p>
                    </div>
                  ))
                )}
              </div>
            )}

            {activeTab === 'stats' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium text-gray-800 mb-4">支出分类统计</h3>
                  <div className="space-y-3">
                    {expenseCategories.map((cat) => {
                      const total = getCategoryTotal(cat);
                      if (total === 0) return null;
                      const percentage = (total / expenses) * 100;
                      return (
                        <div key={cat} className="bg-gray-50 p-4 rounded-lg">
                          <div className="flex justify-between mb-2">
                            <span className="font-medium">{cat}</span>
                            <span className="text-gray-600">¥{total.toFixed(2)}</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div
                              className="bg-indigo-600 h-2.5 rounded-full"
                              style={{ width: `${percentage}%` }}
                            ></div>
                          </div>
                          <span className="text-sm text-gray-500">{percentage.toFixed(1)}%</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium text-gray-800 mb-4">收入来源统计</h3>
                  <div className="space-y-3">
                    {incomeCategories.map((cat) => {
                      const total = getCategoryTotal(cat);
                      if (total === 0) return null;
                      const percentage = (total / income) * 100;
                      return (
                        <div key={cat} className="bg-gray-50 p-4 rounded-lg">
                          <div className="flex justify-between mb-2">
                            <span className="font-medium">{cat}</span>
                            <span className="text-gray-600">¥{total.toFixed(2)}</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div
                              className="bg-green-600 h-2.5 rounded-full"
                              style={{ width: `${percentage}%` }}
                            ></div>
                          </div>
                          <span className="text-sm text-gray-500">{percentage.toFixed(1)}%</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'budget' && (
              <div className="space-y-6">
                <form onSubmit={handleAddBudget} className="bg-gray-50 p-4 rounded-lg space-y-4">
                  <h3 className="font-medium text-gray-800">添加预算</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        分类
                      </label>
                      <select
                        value={newBudgetCategory}
                        onChange={(e) => setNewBudgetCategory(e.target.value as Category)}
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                      >
                        {expenseCategories.map((cat) => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        预算金额
                      </label>
                      <input
                        type="number"
                        value={newBudgetLimit}
                        onChange={(e) => setNewBudgetLimit(e.target.value)}
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                        placeholder="输入预算金额"
                        required
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-indigo-600 text-white py-3 px-4 rounded-lg hover:bg-indigo-700 transition-all duration-200 ease-in-out transform hover:scale-[1.02] hover:shadow-lg active:scale-[0.98] flex items-center justify-center gap-2"
                  >
                    <Target className="w-4 h-4" />
                    <span>设置预算</span>
                  </button>
                </form>

                <div className="space-y-4">
                  <h3 className="font-medium text-gray-800">预算执行情况</h3>
                  {budgets.map((budget) => {
                    const status = getBudgetStatus(budget.category);
                    if (!status) return null;
                    return (
                      <div key={budget.category} className="bg-gray-50 p-4 rounded-lg">
                        <div className="flex justify-between mb-2">
                          <span className="font-medium">{budget.category}</span>
                          <span className="text-gray-600">
                            ¥{status.spent.toFixed(2)} / ¥{status.limit.toFixed(2)}
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div
                            className={`h-2.5 rounded-full ${
                              status.percentage > 100
                                ? 'bg-red-600'
                                : status.percentage > 80
                                ? 'bg-yellow-600'
                                : 'bg-green-600'
                            }`}
                            style={{ width: `${Math.min(status.percentage, 100)}%` }}
                          ></div>
                        </div>
                        <div className="flex justify-between mt-1">
                          <span className="text-sm text-gray-500">
                            {status.percentage.toFixed(1)}%
                          </span>
                          <span className="text-sm text-gray-500">
                            剩余: ¥{status.remaining.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;